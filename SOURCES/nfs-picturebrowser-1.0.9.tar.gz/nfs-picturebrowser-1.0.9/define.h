#ifndef DEFINE
#define DEFINE

#define PICTUREBROWSER ".pictureBrowser"
#define ROWS 6
#define TOOLBARHEIGTH 32
#define THUMBNAILHEIGTH 48
#define SMALLTOOLBARHEIGTH 40
#define SLIDETOOLBARHEIGTH 42
#define DISTANCE 40
#define MINHEIGTH 305
#define MINWEITH 505
#define PICTUREBROWSER_DESKTOP "picturebrowser.desktop"

#endif // DEFINE

