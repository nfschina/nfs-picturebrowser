<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Widget</name>
    <message>
        <location filename="widget.cpp" line="15"/>
        <source>看图工具</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>bigPictureView</name>
    <message>
        <location filename="bigpictureview.cpp" line="132"/>
        <source>&amp;打开图片...                       Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bigpictureview.cpp" line="134"/>
        <source>&amp;复制                                  Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bigpictureview.cpp" line="136"/>
        <source>&amp;删除                                  Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bigpictureview.cpp" line="138"/>
        <source>&amp;另存为...                           Shift+Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bigpictureview.cpp" line="140"/>
        <source>&amp;刷新                                  F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bigpictureview.cpp" line="142"/>
        <source>&amp;设为壁纸</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bigpictureview.cpp" line="143"/>
        <source>&amp;设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bigpictureview.cpp" line="144"/>
        <source>&amp;打印预览</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bigpictureview.cpp" line="145"/>
        <source>&amp;打印</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bigpictureview.cpp" line="551"/>
        <location filename="bigpictureview.cpp" line="715"/>
        <source>已最大</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bigpictureview.cpp" line="570"/>
        <location filename="bigpictureview.cpp" line="746"/>
        <source>已最小</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>habitWidget</name>
    <message>
        <location filename="pagewidget.cpp" line="193"/>
        <source>是否保存窗口大小</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="196"/>
        <source>是</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="197"/>
        <source>否</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>helpWidget</name>
    <message>
        <location filename="pagewidget.cpp" line="431"/>
        <source>:/prefix1/1-images/LOGO.png</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="435"/>
        <source>看图工具</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="444"/>
        <source>version: 未知</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="455"/>
        <source>    看图工具是一款简洁的图片查看器， 设计宗旨是：美观，
易用和快捷。</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mainTaskWidget</name>
    <message>
        <location filename="maintaskwidget.cpp" line="613"/>
        <location filename="maintaskwidget.cpp" line="972"/>
        <location filename="maintaskwidget.cpp" line="993"/>
        <location filename="maintaskwidget.cpp" line="1098"/>
        <source>图片读取中...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="771"/>
        <source>已保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="777"/>
        <source>文件名输入不正确,请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="783"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="783"/>
        <source>此功能正在开发中...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="798"/>
        <source>编辑工具  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="801"/>
        <source>图片编辑</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="909"/>
        <source>警告             </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="909"/>
        <source>请先安装GIMP图片编辑工具</source>
        <comment>确定</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1072"/>
        <source>已删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1112"/>
        <source>确认要删除文件 “</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1112"/>
        <source>” 吗?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1113"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1113"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1114"/>
        <source>覆盖图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1163"/>
        <location filename="maintaskwidget.cpp" line="1232"/>
        <source>保存图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1177"/>
        <location filename="maintaskwidget.cpp" line="1241"/>
        <location filename="maintaskwidget.cpp" line="1331"/>
        <source>正在保存...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1206"/>
        <location filename="maintaskwidget.cpp" line="1428"/>
        <source>您没有权限对当前文件进行更改</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1313"/>
        <source>不保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1313"/>
        <source>另存为</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1314"/>
        <source>覆盖原图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="1316"/>
        <source>图片发生旋转，请选择保存方式?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mainWidget_1</name>
    <message>
        <location filename="mainwidget_1.cpp" line="11"/>
        <source>:/prefix1/1-images/LOGO.png</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwidget_1.cpp" line="14"/>
        <location filename="mainwidget_1.cpp" line="19"/>
        <location filename="mainwidget_1.cpp" line="147"/>
        <source>打开图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwidget_1.cpp" line="15"/>
        <source>小巧轻快 随心浏览...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwidget_1.cpp" line="111"/>
        <source>无法载入图片&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwidget_1.cpp" line="112"/>
        <source>分析:图片文件损坏...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwidget_1.cpp" line="113"/>
        <location filename="mainwidget_1.cpp" line="163"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwidget_1.cpp" line="113"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwidget_1.cpp" line="114"/>
        <source>覆盖原图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwidget_1.cpp" line="154"/>
        <source>Image(*.bmp  *.BMP  *.bitmap  *.gif  *.tif   *.tiff  *.jpg  *.JPG  *.jpeg *.JPEG  *.jpeg2000  *.jpc  *.j2k  *.jpf  *.png  *.PNG  *.pbm *.pgm *.psd  *.jp2  *.ico  *.icns)</source>
        <translation type="unfinished">图像</translation>
    </message>
</context>
<context>
    <name>menuBar</name>
    <message>
        <location filename="slidedialog.cpp" line="28"/>
        <source>增加间隔时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="slidedialog.cpp" line="31"/>
        <source>减少间隔时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="slidedialog.cpp" line="55"/>
        <source>暂停/继续幻灯片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="slidedialog.cpp" line="61"/>
        <source>退出放映</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>moveWidget</name>
    <message>
        <location filename="titlebarwidget.cpp" line="143"/>
        <source>看图工具</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>normalWidget</name>
    <message>
        <location filename="pagewidget.cpp" line="11"/>
        <source>常规设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="16"/>
        <source>标题栏显示图片名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="18"/>
        <source>工具栏默认不隐藏</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="20"/>
        <source>左右翻页箭头不隐藏</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="22"/>
        <source>删除图片时弹出提示框</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="24"/>
        <source>默认打开缩略图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="28"/>
        <source>全屏透明</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="32"/>
        <source>透明</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="33"/>
        <source>不透明</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>picInfoWidget</name>
    <message>
        <location filename="picinfowidget.cpp" line="26"/>
        <source>图片信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="27"/>
        <source>文件信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="90"/>
        <source>名称：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="91"/>
        <source>

类型：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="92"/>
        <source>

尺寸：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="92"/>
        <source> 像素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="93"/>
        <source>

分辨率：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="103"/>
        <source>文件夹路径：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="104"/>
        <source>

创建时间：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="105"/>
        <source>

修改时间：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="106"/>
        <source>

大小：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="picinfowidget.cpp" line="107"/>
        <source>

所有者：</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>scrolledButtonWidget</name>
    <message>
        <location filename="maintaskwidget.cpp" line="52"/>
        <source>上一张</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="maintaskwidget.cpp" line="61"/>
        <source>下一张</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>setUpDialog</name>
    <message>
        <location filename="setupdialog.cpp" line="15"/>
        <source>已恢复默认设置</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>slideDialog</name>
    <message>
        <location filename="slidedialog.cpp" line="451"/>
        <source>第</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="slidedialog.cpp" line="452"/>
        <location filename="slidedialog.cpp" line="569"/>
        <source>张</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="slidedialog.cpp" line="469"/>
        <location filename="slidedialog.cpp" line="485"/>
        <location filename="slidedialog.cpp" line="567"/>
        <source>间隔</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="slidedialog.cpp" line="469"/>
        <location filename="slidedialog.cpp" line="485"/>
        <location filename="slidedialog.cpp" line="567"/>
        <source>秒</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>slideWidget</name>
    <message>
        <location filename="pagewidget.cpp" line="253"/>
        <source>默认播放顺序</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="256"/>
        <source>循环播放</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="257"/>
        <source>随机播放</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="266"/>
        <source>默认播放速度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="269"/>
        <source>播放间隔</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="276"/>
        <source>(范围在1～9秒)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="285"/>
        <source>默认播放效果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="295"/>
        <source>无效果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="296"/>
        <source>快速推入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="297"/>
        <source>淡入淡出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="298"/>
        <source>扇形飞入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="299"/>
        <source>随机效果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="301"/>
        <source>默认背景</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="308"/>
        <source>黑色背景</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pagewidget.cpp" line="309"/>
        <source>花纹背景</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>smallPictureView</name>
    <message>
        <location filename="smallpictureview.cpp" line="321"/>
        <location filename="smallpictureview.cpp" line="365"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="smallpictureview.cpp" line="321"/>
        <location filename="smallpictureview.cpp" line="365"/>
        <source>请先选择图片文件!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>smallToolBarWidget</name>
    <message>
        <location filename="bottomwidget.cpp" line="431"/>
        <source>图片信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="434"/>
        <source>放大</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="437"/>
        <source>缩小</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="439"/>
        <source>美化/编辑图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="441"/>
        <source>将图片分享到...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="445"/>
        <source>上一张</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="448"/>
        <source>下一张</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="451"/>
        <source>适应窗口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="453"/>
        <source>旋转</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="455"/>
        <source>幻灯片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="457"/>
        <source>删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="459"/>
        <source>打开新的图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="461"/>
        <source>固定/隐藏</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="463"/>
        <source>缩略图</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>titleBarWidget</name>
    <message>
        <location filename="titlebarwidget.cpp" line="14"/>
        <source>全屏</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="titlebarwidget.cpp" line="19"/>
        <source>最小化</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="titlebarwidget.cpp" line="24"/>
        <source>最大化</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="titlebarwidget.cpp" line="29"/>
        <source>关闭</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>toolBarWidget</name>
    <message>
        <location filename="bottomwidget.cpp" line="224"/>
        <source>图片信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="227"/>
        <source>放大</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="230"/>
        <source>缩小</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="232"/>
        <source>编辑图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="234"/>
        <source>将图片分享到...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="238"/>
        <source>上一张</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="241"/>
        <source>下一张</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="244"/>
        <location filename="bottomwidget.cpp" line="409"/>
        <source>实际尺寸</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="246"/>
        <source>旋转</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="248"/>
        <source>幻灯片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="250"/>
        <source>删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="252"/>
        <source>打开新的图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="254"/>
        <source>缩略图</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="257"/>
        <source>固定/隐藏</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="397"/>
        <location filename="bottomwidget.cpp" line="408"/>
        <source>全屏显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bottomwidget.cpp" line="398"/>
        <source>适应窗口</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
