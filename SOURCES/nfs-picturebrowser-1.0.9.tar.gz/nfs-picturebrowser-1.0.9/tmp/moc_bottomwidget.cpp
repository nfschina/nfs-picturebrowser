/****************************************************************************
** Meta object code from reading C++ file 'bottomwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../bottomwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'bottomwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_toolBarButton_t {
    QByteArrayData data[1];
    char stringdata0[14];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_toolBarButton_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_toolBarButton_t qt_meta_stringdata_toolBarButton = {
    {
QT_MOC_LITERAL(0, 0, 13) // "toolBarButton"

    },
    "toolBarButton"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_toolBarButton[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void toolBarButton::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject toolBarButton::staticMetaObject = { {
    &QPushButton::staticMetaObject,
    qt_meta_stringdata_toolBarButton.data,
    qt_meta_data_toolBarButton,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *toolBarButton::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *toolBarButton::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_toolBarButton.stringdata0))
        return static_cast<void*>(this);
    return QPushButton::qt_metacast(_clname);
}

int toolBarButton::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QPushButton::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_smallToolBarWidget_t {
    QByteArrayData data[1];
    char stringdata0[19];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_smallToolBarWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_smallToolBarWidget_t qt_meta_stringdata_smallToolBarWidget = {
    {
QT_MOC_LITERAL(0, 0, 18) // "smallToolBarWidget"

    },
    "smallToolBarWidget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_smallToolBarWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void smallToolBarWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject smallToolBarWidget::staticMetaObject = { {
    &QFrame::staticMetaObject,
    qt_meta_stringdata_smallToolBarWidget.data,
    qt_meta_data_smallToolBarWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *smallToolBarWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *smallToolBarWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_smallToolBarWidget.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int smallToolBarWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_toolBarWidget_t {
    QByteArrayData data[5];
    char stringdata0[57];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_toolBarWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_toolBarWidget_t qt_meta_stringdata_toolBarWidget = {
    {
QT_MOC_LITERAL(0, 0, 13), // "toolBarWidget"
QT_MOC_LITERAL(1, 14, 23), // "slot_changeOnetoOneIcon"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 1), // "f"
QT_MOC_LITERAL(4, 41, 15) // "slot_setIsfixed"

    },
    "toolBarWidget\0slot_changeOnetoOneIcon\0"
    "\0f\0slot_setIsfixed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_toolBarWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x0a /* Public */,
       4,    0,   27,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void,

       0        // eod
};

void toolBarWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<toolBarWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->slot_changeOnetoOneIcon((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->slot_setIsfixed(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject toolBarWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_toolBarWidget.data,
    qt_meta_data_toolBarWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *toolBarWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *toolBarWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_toolBarWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int toolBarWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
struct qt_meta_stringdata_bottomWidgt_t {
    QByteArrayData data[9];
    char stringdata0[168];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_bottomWidgt_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_bottomWidgt_t qt_meta_stringdata_bottomWidgt = {
    {
QT_MOC_LITERAL(0, 0, 11), // "bottomWidgt"
QT_MOC_LITERAL(1, 12, 18), // "sig_needSetItemPos"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 31), // "slot_smallPictureViewShowOrHide"
QT_MOC_LITERAL(4, 64, 18), // "slot_showAnimation"
QT_MOC_LITERAL(5, 83, 18), // "slot_hideAnimation"
QT_MOC_LITERAL(6, 102, 25), // "slot_increaseTransparency"
QT_MOC_LITERAL(7, 128, 23), // "slot_reduceTransparency"
QT_MOC_LITERAL(8, 152, 15) // "slot_statTimer2"

    },
    "bottomWidgt\0sig_needSetItemPos\0\0"
    "slot_smallPictureViewShowOrHide\0"
    "slot_showAnimation\0slot_hideAnimation\0"
    "slot_increaseTransparency\0"
    "slot_reduceTransparency\0slot_statTimer2"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_bottomWidgt[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   49,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,   50,    2, 0x0a /* Public */,
       4,    0,   51,    2, 0x0a /* Public */,
       5,    0,   52,    2, 0x0a /* Public */,
       6,    0,   53,    2, 0x0a /* Public */,
       7,    0,   54,    2, 0x0a /* Public */,
       8,    0,   55,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void bottomWidgt::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<bottomWidgt *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sig_needSetItemPos(); break;
        case 1: _t->slot_smallPictureViewShowOrHide(); break;
        case 2: _t->slot_showAnimation(); break;
        case 3: _t->slot_hideAnimation(); break;
        case 4: _t->slot_increaseTransparency(); break;
        case 5: _t->slot_reduceTransparency(); break;
        case 6: _t->slot_statTimer2(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (bottomWidgt::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bottomWidgt::sig_needSetItemPos)) {
                *result = 0;
                return;
            }
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject bottomWidgt::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_bottomWidgt.data,
    qt_meta_data_bottomWidgt,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *bottomWidgt::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *bottomWidgt::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_bottomWidgt.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int bottomWidgt::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void bottomWidgt::sig_needSetItemPos()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
