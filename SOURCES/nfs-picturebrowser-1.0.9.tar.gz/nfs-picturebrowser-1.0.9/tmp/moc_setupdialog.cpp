/****************************************************************************
** Meta object code from reading C++ file 'setupdialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../setupdialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'setupdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_titleBarForSetupDialog_t {
    QByteArrayData data[1];
    char stringdata0[23];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_titleBarForSetupDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_titleBarForSetupDialog_t qt_meta_stringdata_titleBarForSetupDialog = {
    {
QT_MOC_LITERAL(0, 0, 22) // "titleBarForSetupDialog"

    },
    "titleBarForSetupDialog"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_titleBarForSetupDialog[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void titleBarForSetupDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject titleBarForSetupDialog::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_titleBarForSetupDialog.data,
    qt_meta_data_titleBarForSetupDialog,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *titleBarForSetupDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *titleBarForSetupDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_titleBarForSetupDialog.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int titleBarForSetupDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_itemButton_t {
    QByteArrayData data[5];
    char stringdata0[57];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_itemButton_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_itemButton_t qt_meta_stringdata_itemButton = {
    {
QT_MOC_LITERAL(0, 0, 10), // "itemButton"
QT_MOC_LITERAL(1, 11, 11), // "sig_pressed"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 10), // "sig_sendId"
QT_MOC_LITERAL(4, 35, 21) // "slot_cancelBackground"

    },
    "itemButton\0sig_pressed\0\0sig_sendId\0"
    "slot_cancelBackground"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_itemButton[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   29,    2, 0x06 /* Public */,
       3,    1,   30,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,   33,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void itemButton::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<itemButton *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sig_pressed(); break;
        case 1: _t->sig_sendId((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->slot_cancelBackground(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (itemButton::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&itemButton::sig_pressed)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (itemButton::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&itemButton::sig_sendId)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject itemButton::staticMetaObject = { {
    &QFrame::staticMetaObject,
    qt_meta_stringdata_itemButton.data,
    qt_meta_data_itemButton,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *itemButton::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *itemButton::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_itemButton.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int itemButton::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void itemButton::sig_pressed()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void itemButton::sig_sendId(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_bottomWidget_t {
    QByteArrayData data[1];
    char stringdata0[13];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_bottomWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_bottomWidget_t qt_meta_stringdata_bottomWidget = {
    {
QT_MOC_LITERAL(0, 0, 12) // "bottomWidget"

    },
    "bottomWidget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_bottomWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void bottomWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject bottomWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_bottomWidget.data,
    qt_meta_data_bottomWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *bottomWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *bottomWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_bottomWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int bottomWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_setUpDialog_t {
    QByteArrayData data[13];
    char stringdata0[192];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_setUpDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_setUpDialog_t qt_meta_stringdata_setUpDialog = {
    {
QT_MOC_LITERAL(0, 0, 11), // "setUpDialog"
QT_MOC_LITERAL(1, 12, 20), // "sig_sendSlideSetInfo"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 7), // "setInfo"
QT_MOC_LITERAL(4, 42, 18), // "sig_normalSetting1"
QT_MOC_LITERAL(5, 61, 9), // "isChecked"
QT_MOC_LITERAL(6, 71, 18), // "sig_normalSetting2"
QT_MOC_LITERAL(7, 90, 18), // "sig_normalSetting3"
QT_MOC_LITERAL(8, 109, 18), // "sig_normalSetting4"
QT_MOC_LITERAL(9, 128, 18), // "sig_normalSetting5"
QT_MOC_LITERAL(10, 147, 18), // "slot_confirmConfig"
QT_MOC_LITERAL(11, 166, 13), // "slot_recovery"
QT_MOC_LITERAL(12, 180, 11) // "slot_cancel"

    },
    "setUpDialog\0sig_sendSlideSetInfo\0\0"
    "setInfo\0sig_normalSetting1\0isChecked\0"
    "sig_normalSetting2\0sig_normalSetting3\0"
    "sig_normalSetting4\0sig_normalSetting5\0"
    "slot_confirmConfig\0slot_recovery\0"
    "slot_cancel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_setUpDialog[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x06 /* Public */,
       4,    1,   62,    2, 0x06 /* Public */,
       6,    1,   65,    2, 0x06 /* Public */,
       7,    1,   68,    2, 0x06 /* Public */,
       8,    1,   71,    2, 0x06 /* Public */,
       9,    1,   74,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      10,    0,   77,    2, 0x0a /* Public */,
      11,    0,   78,    2, 0x0a /* Public */,
      12,    0,   79,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    5,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void setUpDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<setUpDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sig_sendSlideSetInfo((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->sig_normalSetting1((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->sig_normalSetting2((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->sig_normalSetting3((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->sig_normalSetting4((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->sig_normalSetting5((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->slot_confirmConfig(); break;
        case 7: _t->slot_recovery(); break;
        case 8: _t->slot_cancel(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (setUpDialog::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&setUpDialog::sig_sendSlideSetInfo)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (setUpDialog::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&setUpDialog::sig_normalSetting1)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (setUpDialog::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&setUpDialog::sig_normalSetting2)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (setUpDialog::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&setUpDialog::sig_normalSetting3)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (setUpDialog::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&setUpDialog::sig_normalSetting4)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (setUpDialog::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&setUpDialog::sig_normalSetting5)) {
                *result = 5;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject setUpDialog::staticMetaObject = { {
    &QDialog::staticMetaObject,
    qt_meta_stringdata_setUpDialog.data,
    qt_meta_data_setUpDialog,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *setUpDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *setUpDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_setUpDialog.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int setUpDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void setUpDialog::sig_sendSlideSetInfo(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void setUpDialog::sig_normalSetting1(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void setUpDialog::sig_normalSetting2(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void setUpDialog::sig_normalSetting3(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void setUpDialog::sig_normalSetting4(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void setUpDialog::sig_normalSetting5(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
