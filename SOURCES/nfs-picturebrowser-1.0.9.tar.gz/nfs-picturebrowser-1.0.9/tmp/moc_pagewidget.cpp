/****************************************************************************
** Meta object code from reading C++ file 'pagewidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../pagewidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'pagewidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_checkBox_t {
    QByteArrayData data[1];
    char stringdata0[9];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_checkBox_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_checkBox_t qt_meta_stringdata_checkBox = {
    {
QT_MOC_LITERAL(0, 0, 8) // "checkBox"

    },
    "checkBox"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_checkBox[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void checkBox::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject checkBox::staticMetaObject = { {
    &QCheckBox::staticMetaObject,
    qt_meta_stringdata_checkBox.data,
    qt_meta_data_checkBox,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *checkBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *checkBox::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_checkBox.stringdata0))
        return static_cast<void*>(this);
    return QCheckBox::qt_metacast(_clname);
}

int checkBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCheckBox::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_normalWidget_t {
    QByteArrayData data[14];
    char stringdata0[244];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_normalWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_normalWidget_t qt_meta_stringdata_normalWidget = {
    {
QT_MOC_LITERAL(0, 0, 12), // "normalWidget"
QT_MOC_LITERAL(1, 13, 18), // "sig_normalSetting1"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 9), // "isChecked"
QT_MOC_LITERAL(4, 43, 18), // "sig_normalSetting2"
QT_MOC_LITERAL(5, 62, 18), // "sig_normalSetting3"
QT_MOC_LITERAL(6, 81, 18), // "sig_normalSetting4"
QT_MOC_LITERAL(7, 100, 18), // "sig_normalSetting5"
QT_MOC_LITERAL(8, 119, 9), // "slot_test"
QT_MOC_LITERAL(9, 129, 22), // "slot_normalSetting1_cb"
QT_MOC_LITERAL(10, 152, 22), // "slot_normalSetting2_cb"
QT_MOC_LITERAL(11, 175, 22), // "slot_normalSetting3_cb"
QT_MOC_LITERAL(12, 198, 22), // "slot_normalSetting4_cb"
QT_MOC_LITERAL(13, 221, 22) // "slot_normalSetting5_cb"

    },
    "normalWidget\0sig_normalSetting1\0\0"
    "isChecked\0sig_normalSetting2\0"
    "sig_normalSetting3\0sig_normalSetting4\0"
    "sig_normalSetting5\0slot_test\0"
    "slot_normalSetting1_cb\0slot_normalSetting2_cb\0"
    "slot_normalSetting3_cb\0slot_normalSetting4_cb\0"
    "slot_normalSetting5_cb"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_normalWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   69,    2, 0x06 /* Public */,
       4,    1,   72,    2, 0x06 /* Public */,
       5,    1,   75,    2, 0x06 /* Public */,
       6,    1,   78,    2, 0x06 /* Public */,
       7,    1,   81,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,   84,    2, 0x0a /* Public */,
       9,    0,   85,    2, 0x0a /* Public */,
      10,    0,   86,    2, 0x0a /* Public */,
      11,    0,   87,    2, 0x0a /* Public */,
      12,    0,   88,    2, 0x0a /* Public */,
      13,    0,   89,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void normalWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<normalWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sig_normalSetting1((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->sig_normalSetting2((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->sig_normalSetting3((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->sig_normalSetting4((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->sig_normalSetting5((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->slot_test(); break;
        case 6: _t->slot_normalSetting1_cb(); break;
        case 7: _t->slot_normalSetting2_cb(); break;
        case 8: _t->slot_normalSetting3_cb(); break;
        case 9: _t->slot_normalSetting4_cb(); break;
        case 10: _t->slot_normalSetting5_cb(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (normalWidget::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&normalWidget::sig_normalSetting1)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (normalWidget::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&normalWidget::sig_normalSetting2)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (normalWidget::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&normalWidget::sig_normalSetting3)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (normalWidget::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&normalWidget::sig_normalSetting4)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (normalWidget::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&normalWidget::sig_normalSetting5)) {
                *result = 4;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject normalWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_normalWidget.data,
    qt_meta_data_normalWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *normalWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *normalWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_normalWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int normalWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void normalWidget::sig_normalSetting1(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void normalWidget::sig_normalSetting2(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void normalWidget::sig_normalSetting3(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void normalWidget::sig_normalSetting4(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void normalWidget::sig_normalSetting5(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
struct qt_meta_stringdata_habitWidget_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_habitWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_habitWidget_t qt_meta_stringdata_habitWidget = {
    {
QT_MOC_LITERAL(0, 0, 11) // "habitWidget"

    },
    "habitWidget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_habitWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void habitWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject habitWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_habitWidget.data,
    qt_meta_data_habitWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *habitWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *habitWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_habitWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int habitWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_slideWidget_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_slideWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_slideWidget_t qt_meta_stringdata_slideWidget = {
    {
QT_MOC_LITERAL(0, 0, 11) // "slideWidget"

    },
    "slideWidget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_slideWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void slideWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject slideWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_slideWidget.data,
    qt_meta_data_slideWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *slideWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *slideWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_slideWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int slideWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_helpWidget_t {
    QByteArrayData data[1];
    char stringdata0[11];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_helpWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_helpWidget_t qt_meta_stringdata_helpWidget = {
    {
QT_MOC_LITERAL(0, 0, 10) // "helpWidget"

    },
    "helpWidget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_helpWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void helpWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject helpWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_helpWidget.data,
    qt_meta_data_helpWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *helpWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *helpWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_helpWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int helpWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
