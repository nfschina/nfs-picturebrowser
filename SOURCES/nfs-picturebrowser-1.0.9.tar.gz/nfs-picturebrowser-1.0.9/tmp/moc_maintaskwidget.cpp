/****************************************************************************
** Meta object code from reading C++ file 'maintaskwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../maintaskwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'maintaskwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_saveAsThread_t {
    QByteArrayData data[1];
    char stringdata0[13];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_saveAsThread_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_saveAsThread_t qt_meta_stringdata_saveAsThread = {
    {
QT_MOC_LITERAL(0, 0, 12) // "saveAsThread"

    },
    "saveAsThread"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_saveAsThread[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void saveAsThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject saveAsThread::staticMetaObject = { {
    &QThread::staticMetaObject,
    qt_meta_stringdata_saveAsThread.data,
    qt_meta_data_saveAsThread,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *saveAsThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *saveAsThread::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_saveAsThread.stringdata0))
        return static_cast<void*>(this);
    return QThread::qt_metacast(_clname);
}

int saveAsThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_scrolledButtonWidget_t {
    QByteArrayData data[8];
    char stringdata0[184];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_scrolledButtonWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_scrolledButtonWidget_t qt_meta_stringdata_scrolledButtonWidget = {
    {
QT_MOC_LITERAL(0, 0, 20), // "scrolledButtonWidget"
QT_MOC_LITERAL(1, 21, 30), // "sig_showAnotherDirectionButton"
QT_MOC_LITERAL(2, 52, 0), // ""
QT_MOC_LITERAL(3, 53, 30), // "sig_hideAnotherDirectionButton"
QT_MOC_LITERAL(4, 84, 25), // "slot_increaseTransparency"
QT_MOC_LITERAL(5, 110, 23), // "slot_reduceTransparency"
QT_MOC_LITERAL(6, 134, 24), // "slot_showDirectionButton"
QT_MOC_LITERAL(7, 159, 24) // "slot_hideDirectionButton"

    },
    "scrolledButtonWidget\0"
    "sig_showAnotherDirectionButton\0\0"
    "sig_hideAnotherDirectionButton\0"
    "slot_increaseTransparency\0"
    "slot_reduceTransparency\0"
    "slot_showDirectionButton\0"
    "slot_hideDirectionButton"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_scrolledButtonWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   44,    2, 0x06 /* Public */,
       3,    0,   45,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,   46,    2, 0x0a /* Public */,
       5,    0,   47,    2, 0x0a /* Public */,
       6,    0,   48,    2, 0x0a /* Public */,
       7,    0,   49,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void scrolledButtonWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<scrolledButtonWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sig_showAnotherDirectionButton(); break;
        case 1: _t->sig_hideAnotherDirectionButton(); break;
        case 2: _t->slot_increaseTransparency(); break;
        case 3: _t->slot_reduceTransparency(); break;
        case 4: _t->slot_showDirectionButton(); break;
        case 5: _t->slot_hideDirectionButton(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (scrolledButtonWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&scrolledButtonWidget::sig_showAnotherDirectionButton)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (scrolledButtonWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&scrolledButtonWidget::sig_hideAnotherDirectionButton)) {
                *result = 1;
                return;
            }
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject scrolledButtonWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_scrolledButtonWidget.data,
    qt_meta_data_scrolledButtonWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *scrolledButtonWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *scrolledButtonWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_scrolledButtonWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int scrolledButtonWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void scrolledButtonWidget::sig_showAnotherDirectionButton()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void scrolledButtonWidget::sig_hideAnotherDirectionButton()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
struct qt_meta_stringdata_mainTaskWidget_t {
    QByteArrayData data[58];
    char stringdata0[969];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_mainTaskWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_mainTaskWidget_t qt_meta_stringdata_mainTaskWidget = {
    {
QT_MOC_LITERAL(0, 0, 14), // "mainTaskWidget"
QT_MOC_LITERAL(1, 15, 20), // "sig_showDirectionKey"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 20), // "sig_hideLeftAndRight"
QT_MOC_LITERAL(4, 58, 17), // "sig_showBottomCtl"
QT_MOC_LITERAL(5, 76, 15), // "sig_hideToolBar"
QT_MOC_LITERAL(6, 92, 20), // "sig_showBottomWidget"
QT_MOC_LITERAL(7, 113, 20), // "sig_hideBottomWidget"
QT_MOC_LITERAL(8, 134, 20), // "sig_sendToInfoWidget"
QT_MOC_LITERAL(9, 155, 9), // "QFileInfo"
QT_MOC_LITERAL(10, 165, 13), // "sig_removeImg"
QT_MOC_LITERAL(11, 179, 14), // "sig_changePage"
QT_MOC_LITERAL(12, 194, 16), // "sig_saveAsDialog"
QT_MOC_LITERAL(13, 211, 14), // "sig_saveDialog"
QT_MOC_LITERAL(14, 226, 15), // "sig_picInfoOpen"
QT_MOC_LITERAL(15, 242, 16), // "sig_picInfoClose"
QT_MOC_LITERAL(16, 259, 18), // "sig_normalSetting1"
QT_MOC_LITERAL(17, 278, 9), // "ischecked"
QT_MOC_LITERAL(18, 288, 23), // "slot_determineCursorPos"
QT_MOC_LITERAL(19, 312, 19), // "slot_receivePicFile"
QT_MOC_LITERAL(20, 332, 9), // "slot_prev"
QT_MOC_LITERAL(21, 342, 9), // "slot_next"
QT_MOC_LITERAL(22, 352, 13), // "slot_openFile"
QT_MOC_LITERAL(23, 366, 14), // "slot_removeImg"
QT_MOC_LITERAL(24, 381, 12), // "slot_copyImg"
QT_MOC_LITERAL(25, 394, 11), // "slot_saveAs"
QT_MOC_LITERAL(26, 406, 17), // "slot_saveAsDialog"
QT_MOC_LITERAL(27, 424, 12), // "slot_refresh"
QT_MOC_LITERAL(28, 437, 9), // "slot_save"
QT_MOC_LITERAL(29, 447, 15), // "slot_saveDialog"
QT_MOC_LITERAL(30, 463, 28), // "slot_showOrHidePicInfoWidget"
QT_MOC_LITERAL(31, 492, 20), // "slot_updataThreadNum"
QT_MOC_LITERAL(32, 513, 20), // "slot_receiveFromView"
QT_MOC_LITERAL(33, 534, 3), // "num"
QT_MOC_LITERAL(34, 538, 18), // "slot_reciveImgInfo"
QT_MOC_LITERAL(35, 557, 14), // "slot_showSlide"
QT_MOC_LITERAL(36, 572, 20), // "slot_opensetUpDialog"
QT_MOC_LITERAL(37, 593, 14), // "slot_slideQuit"
QT_MOC_LITERAL(38, 608, 15), // "slot_finishSave"
QT_MOC_LITERAL(39, 624, 18), // "slot_setAllItemPos"
QT_MOC_LITERAL(40, 643, 18), // "slot_openSelectbox"
QT_MOC_LITERAL(41, 662, 27), // "slot_OpenPictureEditingTool"
QT_MOC_LITERAL(42, 690, 17), // "slot_sharePicture"
QT_MOC_LITERAL(43, 708, 18), // "slot_radioBtnCheck"
QT_MOC_LITERAL(44, 727, 26), // "slot_fileInfoThreadFinshed"
QT_MOC_LITERAL(45, 754, 16), // "slot_picInfoOpen"
QT_MOC_LITERAL(46, 771, 19), // "slot_normalSetting2"
QT_MOC_LITERAL(47, 791, 19), // "slot_normalSetting3"
QT_MOC_LITERAL(48, 811, 19), // "slot_normalSetting4"
QT_MOC_LITERAL(49, 831, 19), // "slot_normalSetting5"
QT_MOC_LITERAL(50, 851, 21), // "slot_recvSlideSetInfo"
QT_MOC_LITERAL(51, 873, 7), // "setInfo"
QT_MOC_LITERAL(52, 881, 17), // "slot_picInfoClose"
QT_MOC_LITERAL(53, 899, 17), // "slot_printpreview"
QT_MOC_LITERAL(54, 917, 10), // "slot_print"
QT_MOC_LITERAL(55, 928, 16), // "printPreviewSlot"
QT_MOC_LITERAL(56, 945, 9), // "QPrinter*"
QT_MOC_LITERAL(57, 955, 13) // "printerPixmap"

    },
    "mainTaskWidget\0sig_showDirectionKey\0"
    "\0sig_hideLeftAndRight\0sig_showBottomCtl\0"
    "sig_hideToolBar\0sig_showBottomWidget\0"
    "sig_hideBottomWidget\0sig_sendToInfoWidget\0"
    "QFileInfo\0sig_removeImg\0sig_changePage\0"
    "sig_saveAsDialog\0sig_saveDialog\0"
    "sig_picInfoOpen\0sig_picInfoClose\0"
    "sig_normalSetting1\0ischecked\0"
    "slot_determineCursorPos\0slot_receivePicFile\0"
    "slot_prev\0slot_next\0slot_openFile\0"
    "slot_removeImg\0slot_copyImg\0slot_saveAs\0"
    "slot_saveAsDialog\0slot_refresh\0slot_save\0"
    "slot_saveDialog\0slot_showOrHidePicInfoWidget\0"
    "slot_updataThreadNum\0slot_receiveFromView\0"
    "num\0slot_reciveImgInfo\0slot_showSlide\0"
    "slot_opensetUpDialog\0slot_slideQuit\0"
    "slot_finishSave\0slot_setAllItemPos\0"
    "slot_openSelectbox\0slot_OpenPictureEditingTool\0"
    "slot_sharePicture\0slot_radioBtnCheck\0"
    "slot_fileInfoThreadFinshed\0slot_picInfoOpen\0"
    "slot_normalSetting2\0slot_normalSetting3\0"
    "slot_normalSetting4\0slot_normalSetting5\0"
    "slot_recvSlideSetInfo\0setInfo\0"
    "slot_picInfoClose\0slot_printpreview\0"
    "slot_print\0printPreviewSlot\0QPrinter*\0"
    "printerPixmap"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_mainTaskWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      50,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      14,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  264,    2, 0x06 /* Public */,
       3,    0,  265,    2, 0x06 /* Public */,
       4,    0,  266,    2, 0x06 /* Public */,
       5,    0,  267,    2, 0x06 /* Public */,
       6,    0,  268,    2, 0x06 /* Public */,
       7,    0,  269,    2, 0x06 /* Public */,
       8,    2,  270,    2, 0x06 /* Public */,
      10,    0,  275,    2, 0x06 /* Public */,
      11,    0,  276,    2, 0x06 /* Public */,
      12,    0,  277,    2, 0x06 /* Public */,
      13,    0,  278,    2, 0x06 /* Public */,
      14,    0,  279,    2, 0x06 /* Public */,
      15,    0,  280,    2, 0x06 /* Public */,
      16,    1,  281,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      18,    1,  284,    2, 0x0a /* Public */,
      19,    1,  287,    2, 0x0a /* Public */,
      20,    0,  290,    2, 0x0a /* Public */,
      21,    0,  291,    2, 0x0a /* Public */,
      22,    0,  292,    2, 0x0a /* Public */,
      23,    0,  293,    2, 0x0a /* Public */,
      24,    0,  294,    2, 0x0a /* Public */,
      25,    0,  295,    2, 0x0a /* Public */,
      26,    0,  296,    2, 0x0a /* Public */,
      27,    0,  297,    2, 0x0a /* Public */,
      28,    0,  298,    2, 0x0a /* Public */,
      29,    0,  299,    2, 0x0a /* Public */,
      30,    0,  300,    2, 0x0a /* Public */,
      31,    0,  301,    2, 0x0a /* Public */,
      32,    1,  302,    2, 0x0a /* Public */,
      34,    2,  305,    2, 0x0a /* Public */,
      35,    0,  310,    2, 0x0a /* Public */,
      36,    0,  311,    2, 0x0a /* Public */,
      37,    1,  312,    2, 0x0a /* Public */,
      38,    0,  315,    2, 0x0a /* Public */,
      39,    0,  316,    2, 0x0a /* Public */,
      40,    0,  317,    2, 0x0a /* Public */,
      41,    1,  318,    2, 0x0a /* Public */,
      42,    0,  321,    2, 0x0a /* Public */,
      43,    0,  322,    2, 0x0a /* Public */,
      44,    0,  323,    2, 0x0a /* Public */,
      45,    0,  324,    2, 0x0a /* Public */,
      46,    1,  325,    2, 0x0a /* Public */,
      47,    1,  328,    2, 0x0a /* Public */,
      48,    1,  331,    2, 0x0a /* Public */,
      49,    1,  334,    2, 0x0a /* Public */,
      50,    1,  337,    2, 0x0a /* Public */,
      52,    0,  340,    2, 0x0a /* Public */,
      53,    0,  341,    2, 0x0a /* Public */,
      54,    0,  342,    2, 0x0a /* Public */,
      55,    1,  343,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9, QMetaType::QStringList,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,

 // slots: parameters
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   33,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void, QMetaType::QString,   51,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 56,   57,

       0        // eod
};

void mainTaskWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<mainTaskWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sig_showDirectionKey(); break;
        case 1: _t->sig_hideLeftAndRight(); break;
        case 2: _t->sig_showBottomCtl(); break;
        case 3: _t->sig_hideToolBar(); break;
        case 4: _t->sig_showBottomWidget(); break;
        case 5: _t->sig_hideBottomWidget(); break;
        case 6: _t->sig_sendToInfoWidget((*reinterpret_cast< const QFileInfo(*)>(_a[1])),(*reinterpret_cast< const QStringList(*)>(_a[2]))); break;
        case 7: _t->sig_removeImg(); break;
        case 8: _t->sig_changePage(); break;
        case 9: _t->sig_saveAsDialog(); break;
        case 10: _t->sig_saveDialog(); break;
        case 11: _t->sig_picInfoOpen(); break;
        case 12: _t->sig_picInfoClose(); break;
        case 13: _t->sig_normalSetting1((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->slot_determineCursorPos((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 15: _t->slot_receivePicFile((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 16: _t->slot_prev(); break;
        case 17: _t->slot_next(); break;
        case 18: _t->slot_openFile(); break;
        case 19: _t->slot_removeImg(); break;
        case 20: _t->slot_copyImg(); break;
        case 21: _t->slot_saveAs(); break;
        case 22: _t->slot_saveAsDialog(); break;
        case 23: _t->slot_refresh(); break;
        case 24: _t->slot_save(); break;
        case 25: _t->slot_saveDialog(); break;
        case 26: _t->slot_showOrHidePicInfoWidget(); break;
        case 27: _t->slot_updataThreadNum(); break;
        case 28: _t->slot_receiveFromView((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 29: _t->slot_reciveImgInfo((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 30: _t->slot_showSlide(); break;
        case 31: _t->slot_opensetUpDialog(); break;
        case 32: _t->slot_slideQuit((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 33: _t->slot_finishSave(); break;
        case 34: _t->slot_setAllItemPos(); break;
        case 35: _t->slot_openSelectbox(); break;
        case 36: _t->slot_OpenPictureEditingTool((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 37: _t->slot_sharePicture(); break;
        case 38: _t->slot_radioBtnCheck(); break;
        case 39: _t->slot_fileInfoThreadFinshed(); break;
        case 40: _t->slot_picInfoOpen(); break;
        case 41: _t->slot_normalSetting2((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 42: _t->slot_normalSetting3((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 43: _t->slot_normalSetting4((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 44: _t->slot_normalSetting5((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 45: _t->slot_recvSlideSetInfo((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 46: _t->slot_picInfoClose(); break;
        case 47: _t->slot_printpreview(); break;
        case 48: _t->slot_print(); break;
        case 49: _t->printPreviewSlot((*reinterpret_cast< QPrinter*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QFileInfo >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_showDirectionKey)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_hideLeftAndRight)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_showBottomCtl)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_hideToolBar)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_showBottomWidget)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_hideBottomWidget)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)(const QFileInfo & , const QStringList & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_sendToInfoWidget)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_removeImg)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_changePage)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_saveAsDialog)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_saveDialog)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_picInfoOpen)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_picInfoClose)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (mainTaskWidget::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mainTaskWidget::sig_normalSetting1)) {
                *result = 13;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject mainTaskWidget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_mainTaskWidget.data,
    qt_meta_data_mainTaskWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *mainTaskWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *mainTaskWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_mainTaskWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int mainTaskWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 50)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 50;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 50)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 50;
    }
    return _id;
}

// SIGNAL 0
void mainTaskWidget::sig_showDirectionKey()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void mainTaskWidget::sig_hideLeftAndRight()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void mainTaskWidget::sig_showBottomCtl()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void mainTaskWidget::sig_hideToolBar()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void mainTaskWidget::sig_showBottomWidget()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void mainTaskWidget::sig_hideBottomWidget()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void mainTaskWidget::sig_sendToInfoWidget(const QFileInfo & _t1, const QStringList & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void mainTaskWidget::sig_removeImg()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void mainTaskWidget::sig_changePage()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void mainTaskWidget::sig_saveAsDialog()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void mainTaskWidget::sig_saveDialog()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void mainTaskWidget::sig_picInfoOpen()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void mainTaskWidget::sig_picInfoClose()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void mainTaskWidget::sig_normalSetting1(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
