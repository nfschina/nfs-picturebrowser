/****************************************************************************
** Meta object code from reading C++ file 'bigpictureview.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../bigpictureview.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'bigpictureview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_bigPictureView_t {
    QByteArrayData data[25];
    char stringdata0[399];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_bigPictureView_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_bigPictureView_t qt_meta_stringdata_bigPictureView = {
    {
QT_MOC_LITERAL(0, 0, 14), // "bigPictureView"
QT_MOC_LITERAL(1, 15, 15), // "sig_doubleClick"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 15), // "sig_singleClick"
QT_MOC_LITERAL(4, 48, 18), // "sig_mapToParentPos"
QT_MOC_LITERAL(5, 67, 1), // "p"
QT_MOC_LITERAL(6, 69, 14), // "sig_changeIcon"
QT_MOC_LITERAL(7, 84, 19), // "sig_triggeredDelete"
QT_MOC_LITERAL(8, 104, 21), // "sig_triggeredOpenfile"
QT_MOC_LITERAL(9, 126, 19), // "sig_triggeredSaveas"
QT_MOC_LITERAL(10, 146, 17), // "sig_triggeredCopy"
QT_MOC_LITERAL(11, 164, 18), // "sig_triggeredSetup"
QT_MOC_LITERAL(12, 183, 20), // "sig_triggeredRefresh"
QT_MOC_LITERAL(13, 204, 17), // "sig_triggeredSave"
QT_MOC_LITERAL(14, 222, 25), // "sig_triggeredPrintPreview"
QT_MOC_LITERAL(15, 248, 18), // "sig_triggeredPrint"
QT_MOC_LITERAL(16, 267, 16), // "slot_rotateImage"
QT_MOC_LITERAL(17, 284, 16), // "slot_largerImage"
QT_MOC_LITERAL(18, 301, 16), // "slot_reduceImage"
QT_MOC_LITERAL(19, 318, 19), // "slot_setAsWallpaper"
QT_MOC_LITERAL(20, 338, 14), // "slot_tipLbHide"
QT_MOC_LITERAL(21, 353, 18), // "slot_receiveOriImg"
QT_MOC_LITERAL(22, 372, 3), // "img"
QT_MOC_LITERAL(23, 376, 8), // "filename"
QT_MOC_LITERAL(24, 385, 13) // "slot_oneToOne"

    },
    "bigPictureView\0sig_doubleClick\0\0"
    "sig_singleClick\0sig_mapToParentPos\0p\0"
    "sig_changeIcon\0sig_triggeredDelete\0"
    "sig_triggeredOpenfile\0sig_triggeredSaveas\0"
    "sig_triggeredCopy\0sig_triggeredSetup\0"
    "sig_triggeredRefresh\0sig_triggeredSave\0"
    "sig_triggeredPrintPreview\0sig_triggeredPrint\0"
    "slot_rotateImage\0slot_largerImage\0"
    "slot_reduceImage\0slot_setAsWallpaper\0"
    "slot_tipLbHide\0slot_receiveOriImg\0img\0"
    "filename\0slot_oneToOne"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_bigPictureView[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  114,    2, 0x06 /* Public */,
       3,    0,  115,    2, 0x06 /* Public */,
       4,    1,  116,    2, 0x06 /* Public */,
       6,    1,  119,    2, 0x06 /* Public */,
       7,    0,  122,    2, 0x06 /* Public */,
       8,    0,  123,    2, 0x06 /* Public */,
       9,    0,  124,    2, 0x06 /* Public */,
      10,    0,  125,    2, 0x06 /* Public */,
      11,    0,  126,    2, 0x06 /* Public */,
      12,    0,  127,    2, 0x06 /* Public */,
      13,    0,  128,    2, 0x06 /* Public */,
      14,    0,  129,    2, 0x06 /* Public */,
      15,    0,  130,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      16,    0,  131,    2, 0x0a /* Public */,
      17,    0,  132,    2, 0x0a /* Public */,
      18,    0,  133,    2, 0x0a /* Public */,
      19,    0,  134,    2, 0x0a /* Public */,
      20,    0,  135,    2, 0x0a /* Public */,
      21,    2,  136,    2, 0x0a /* Public */,
      24,    0,  141,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,    5,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QImage, QMetaType::QString,   22,   23,
    QMetaType::Void,

       0        // eod
};

void bigPictureView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<bigPictureView *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sig_doubleClick(); break;
        case 1: _t->sig_singleClick(); break;
        case 2: _t->sig_mapToParentPos((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 3: _t->sig_changeIcon((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->sig_triggeredDelete(); break;
        case 5: _t->sig_triggeredOpenfile(); break;
        case 6: _t->sig_triggeredSaveas(); break;
        case 7: _t->sig_triggeredCopy(); break;
        case 8: _t->sig_triggeredSetup(); break;
        case 9: _t->sig_triggeredRefresh(); break;
        case 10: _t->sig_triggeredSave(); break;
        case 11: _t->sig_triggeredPrintPreview(); break;
        case 12: _t->sig_triggeredPrint(); break;
        case 13: _t->slot_rotateImage(); break;
        case 14: _t->slot_largerImage(); break;
        case 15: _t->slot_reduceImage(); break;
        case 16: _t->slot_setAsWallpaper(); break;
        case 17: _t->slot_tipLbHide(); break;
        case 18: _t->slot_receiveOriImg((*reinterpret_cast< const QImage(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 19: _t->slot_oneToOne(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_doubleClick)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_singleClick)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)(QPoint );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_mapToParentPos)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_changeIcon)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_triggeredDelete)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_triggeredOpenfile)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_triggeredSaveas)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_triggeredCopy)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_triggeredSetup)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_triggeredRefresh)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_triggeredSave)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_triggeredPrintPreview)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (bigPictureView::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&bigPictureView::sig_triggeredPrint)) {
                *result = 12;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject bigPictureView::staticMetaObject = { {
    &QGraphicsView::staticMetaObject,
    qt_meta_stringdata_bigPictureView.data,
    qt_meta_data_bigPictureView,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *bigPictureView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *bigPictureView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_bigPictureView.stringdata0))
        return static_cast<void*>(this);
    return QGraphicsView::qt_metacast(_clname);
}

int bigPictureView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
    return _id;
}

// SIGNAL 0
void bigPictureView::sig_doubleClick()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void bigPictureView::sig_singleClick()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void bigPictureView::sig_mapToParentPos(QPoint _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void bigPictureView::sig_changeIcon(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void bigPictureView::sig_triggeredDelete()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void bigPictureView::sig_triggeredOpenfile()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void bigPictureView::sig_triggeredSaveas()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void bigPictureView::sig_triggeredCopy()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void bigPictureView::sig_triggeredSetup()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void bigPictureView::sig_triggeredRefresh()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void bigPictureView::sig_triggeredSave()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void bigPictureView::sig_triggeredPrintPreview()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void bigPictureView::sig_triggeredPrint()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
