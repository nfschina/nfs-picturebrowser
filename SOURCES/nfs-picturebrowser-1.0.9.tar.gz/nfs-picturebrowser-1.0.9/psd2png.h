#ifndef PSD2PNG
#define PSD2PNG
#include <iostream>
#include <fstream>
#include <QString>

QString psd2png(QString &fileName,QString &desName);

#endif // PSD2PNG

