#ifndef LOADFILEOBJ_H
#define LOADFILEOBJ_H

#include "common.h"
#include "messagebox.h"

QString openFileDialog(QWidget *_parent, const QString defaultDir = NULL);

#endif // LOADFILEOBJ_H
